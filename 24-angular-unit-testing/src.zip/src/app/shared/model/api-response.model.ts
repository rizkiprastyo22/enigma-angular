export interface ApiResponse<T>{
    "code": 200,
    "status": "OK",
    "message": "User signed in successfully",
    "data": T
}